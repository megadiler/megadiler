--drop table bfo_xml;
create table bfo_xml (
id number,
inn varchar2(10),
fileName varchar2(128),
fileType varchar2(16),
reportType varchar2(16),
period number,
uploadDate date,
token varchar2(50),
xmlfile xmltype,
page number default null, 
download_date date default null,
status varchar2(16) default null
); commit;
grant SELECT on "SB_DKA"."BFO_XML" to "SB_DMAS" ;
commit;

--select page, count(inn) from sb_dka.bfo_xml_test group by page   order by 1
--select count(*) from sb_dka.bfo_xml --where xmlfile is not null

--delete from bfo_xml where page = 206; commit;
--drop table bfo_xml;
--truncate table bfo_xml2; commit;

    select count(*) from sb_dka.bfo_tokens tlbA 
    left join sb_dka.bfo_xml tlbB on tlbA.inn = tlbB.inn 
    and tlbB.period = 2022 and tlbA.period = 2022
    where tlbB.inn is NUll 
    
    --select count(*) from (
    select count( distinct inn) from sb_dka.bfo_tokens where period = 2022 --group by inn having count(inn) > 1
    --)

select count(*) from sb_dka.bfo_xml --where xmlfile is not null
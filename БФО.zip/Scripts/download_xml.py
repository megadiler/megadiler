'''
скрипт для скачивания XML
'''
import sys, os
import requests
import urllib3
import xml.etree.ElementTree as ET
import oracledb as odb
import time

from time import sleep
from datetime import datetime, date

urllib3.disable_warnings()

getFileError = 0
ODB_amount = 0 
success_amount = 0
empty_amount = 0
size_amount = 0

def getToken():
    url_main = 'https://api-bo.nalog.ru/oauth/token' #ссылка на получение токена авторизации
    header_main = {'Accept': '*/*', 'Authorization': 'Basic YXBpOjEyMzQ1Njc4OTA=', 'User-Agent': 'curl/7.82.0'} #настройки для запроса авторизации
    data_main={'grant_type':'password','username':'otstavnovav@uralsib.ru','password':'Ddu!48Az'} #данные для авторизации    
    resp_main = requests.post(url_main, verify=False, headers=header_main, data = data_main) #запрос на получение токена авторизации
    tokenT0 = time.time()    
    token = None
    header = ''
    if resp_main.status_code != requests.codes.ok:
        print('ошибка получения token')
    else:    
        token = resp_main.json()['access_token'] #получаем токен из ответа
        expires_in = resp_main.json()['expires_in']
        header = {'Authorization': 'Bearer '+token, 'User-Agent': 'curl/7.37.1'} #настройки для запроса списка файлов
    print('token: ', token)
    print('expires_in:', expires_in)
    return (token, expires_in, tokenT0, header)    

def getFileTokens(report_year, token, page, size, header):
    url = 'https://api-bo.nalog.ru/api/v1/files/?period=2022' #ссылка для получения списка файлов    
    data={'period': str(report_year), 'fileType': 'BFO', 'reportType': 'BFO_TKS', 'size': str(size), 'sort': 'inn', 'page': str(page)} #данные для запроса списка файлов    
    resp = requests.get(url, verify=False, headers=header, params = data) #запрос с проверкой на ошибку        
    return (resp.status_code, resp.json())          

def getFile(token, header):
    resp_file = None
    try: 
        resp_file = requests.get('https://api-bo.nalog.ru/api/v1/files/' + token, verify=False, headers=header) #запрос на получение файла
        #print('get file status_code: {}'.format(resp_file.status_code))
        if resp_file.status_code == requests.codes.ok:
            if resp_file.text == '':
                print('файл пустой')
            #print('len = {}'.format(len(resp_file.text)))
    except:
        print('ошибка получения файла')
    return (resp_file.status_code, resp_file)    

def getConnDB(schema):
    ''' SB_DMAS / SB_DKA'''
    odb.init_oracle_client()
    if schema == 'SB_DMAS':
        User = 'SB_DMAS'
        Psw = '*'
    elif schema == 'SB_DKA':
        User = '[SB_DKA]'
        Psw = '*'
    else: 
        return None    
    Params = odb.ConnectParams(host='e30-scan.fc.uralsibbank.ru', port='1522', service_name = 'cdw.work')
    conn_db = odb.connect(user=User, password=Psw, params = Params)
    print('conn_db: {}'.format(conn_db))
    return conn_db

print('Start download XML')

# получение таблицы с токенами
conn_db = getConnDB('SB_DKA')
cursor = conn_db.cursor()

query = '''
    select tlbA.* from sb_dka.bfo_tokens tlbA  \
    left join sb_dka.bfo_xml tlbB on tlbA.inn = tlbB.inn  \
    where tlbB.inn is NUll \
    and tlbA.period = 2022 \
    order by tlbA.page'''
cursor.execute(query)

rows = cursor.fetchall()
rowsSize = len(rows)
print('rows.size = {}'.format(rowsSize))
if rowsSize == 0: pass

# получение токена авторизации
time_start = datetime.now().strftime('%H:%M')
T0 = time.time()
(tokenAuth, expires, tokenT0, header) = getToken()

# по всем token
allInput = []
for indx, row in enumerate(rows):
    #if indx > 200: break
    #if indx % 5 == 0: 
        #delta_time = round((time.time() - T0)/60, 1)                
        #print('D(t)= {}, indx= {}, OK= {}, getFileError= {}, empty={}'.format(delta_time, indx, success_amount, getFileError, empty_amount))

    inn = row[1]
    fileToken = row[7]
    delta = time.time() - tokenT0
    if delta >= expires:
        (tokenAuth, expires, tokenT0, header) = getToken()

    # получение файла
    (getFileStatus, fileXML) = getFile(fileToken, header)
    if getFileStatus == requests.codes.ok:  
        success_amount += 1
        status = 'файл получен'
        if len(fileXML.text) == 0:
            status = 'получен пустой файл'
            empty_amount += 1
            continue
        #print('encoding=',fileXML.apparent_encoding)
        if fileXML.apparent_encoding != 'windows-1251':
            #print('encoding = ', fileXML.apparent_encoding)
            if fileXML.apparent_encoding == 'MacCyrillic':
                fileXML.encoding = 'windows-1251'
            if fileXML.apparent_encoding == 'KOI8-R':
                fileXML.encoding = 'windows-1251'
            if fileXML.apparent_encoding == 'mac_greek':
                fileXML.encoding = 'windows-1251'
            #nowin1251_amount += 1
            #continue

        rowInput = (row[0], inn, row[2], row[3], row[4], row[5], row[6], fileToken, fileXML.text, row[8], date.today(), status)                        
        allInput.append(rowInput)
        if len(allInput) >= 1 :
            try:
                cursor.executemany('insert into bfo_xml values (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11, :12)', allInput)
                conn_db.commit()
                allInput.clear()
            except odb.Error as e:  
                er = e.args
                ODB_amount += 1
                allInput.clear()
                print('[{}] commit Error {}, inn={}'.format(datetime.now().strftime('%H:%M') ,ODB_amount, inn))                
            #else:
            #    print('commit OK')
    else:
        getFileError += 1            
    if ODB_amount >= 20: break

print('GetFileError ', getFileError)                
print('success_amount= ', success_amount)                
print('ODB_amount= ', ODB_amount)                
print('empty_amount= ', empty_amount)                
delta_time = round((time.time() - T0)/60, 1)                
print('D(t)= {}'.format(delta_time))                
print('время: {} '.format(datetime.now().strftime('%H:%M')))
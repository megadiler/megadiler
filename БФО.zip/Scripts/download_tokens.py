'''
скрипт для скачивания token
'''
import sys, os, time
import requests
import urllib3
import xml.etree.ElementTree as ET
import oracledb as odb
from datetime import datetime, date

urllib3.disable_warnings()

error_amount = 0 
success_amount = 0
empty_amount = 0
size_amount = 0

def getToken():
    url_main = 'https://api-bo.nalog.ru/oauth/token' #ссылка на получение токена авторизации
    header_main = {'Accept': '*/*', 'Authorization': 'Basic YXBpOjEyMzQ1Njc4OTA=', 'User-Agent': 'curl/7.82.0'} #настройки для запроса авторизации
    data_main={'grant_type':'password','username':'otstavnovav@uralsib.ru','password':'Ddu!48Az'} #данные для авторизации    
    resp_main = requests.post(url_main, verify=False, headers=header_main, data = data_main) #запрос на получение токена авторизации
    tokenT0 = time.time()    
    token = None
    header = ''
    if resp_main.status_code != requests.codes.ok:
        print('ошибка получения token')
    else:    
        token = resp_main.json()['access_token'] #получаем токен из ответа
        expires_in = resp_main.json()['expires_in']
        header = {'Authorization': 'Bearer '+token, 'User-Agent': 'curl/7.37.1'} #настройки для запроса списка файлов
    print('token: ', token)
    print('expires_in:', expires_in)
    print('tokenT0: ', tokenT0)
    return (token, expires_in, tokenT0, header)    

def getPageAmount(report_year, token, size, header):
    url = 'https://api-bo.nalog.ru/api/v1/files/?period={}'.format(str(report_year)) #ссылка для получения списка файлов    
    data={'period': str(report_year), 'fileType': 'BFO', 'reportType': 'BFO_TKS', 'size': str(size)} 
    resp = requests.get(url, verify=False, headers=header, params = data) #запрос с проверкой на ошибку        
    totalPages = None    
    status = resp.status_code
    if status == requests.codes.ok:
        totalPages = resp.json()['totalPages']
    return (status, totalPages)          

def getFileTokens(report_year, token, page, size, header):
    url = 'https://api-bo.nalog.ru/api/v1/files/?period={}'.format(str(report_year)) #ссылка для получения списка файлов    
    data={'period': str(report_year), 'fileType': 'BFO', 'reportType': 'BFO_TKS', 'size': str(size), 'sort': 'inn', 'page': str(page)} #данные для запроса списка файлов    
    resp = requests.get(url, verify=False, headers=header, params = data) #запрос с проверкой на ошибку        
    return (resp.status_code, resp.json())          

def getFile(token, header):
    resp_file = None
    try: 
        resp_file = requests.get('https://api-bo.nalog.ru/api/v1/files/' + token, verify=False, headers=header) #запрос на получение файла
        #print('get file status_code: {}'.format(resp_file.status_code))
        if resp_file.status_code == requests.codes.ok:
            if resp_file.text == '':
                print('файл пустой')
            #print('len = {}'.format(len(resp_file.text)))
    except:
        print('ошибка получения файла')
    return (resp_file.status_code, resp_file)    

# 
def SavePage2db(data, page):
    global error_amount, success_amount, empty_amount, size_amount, T0, conn_db
    # по всем токенам страницы
    for indx, iter in enumerate(data['content']): 
        id = iter['id']
        inn = iter['inn']        
        fileName = iter['fileName']        
        fileType = iter['fileType']        
        reportType = iter['reportType']        
        period = int(iter['period'])
        uploadDate = datetime.strptime( iter['uploadDate'], '%Y-%m-%d')
        token = iter['token']
        status = 'Токен получен'
        with conn_db.cursor() as cursor:
            success_amount += 1
            row = [id, inn, fileName, fileType, reportType, period, uploadDate, token, page, date.today(), status]                        
            cursor.execute('insert into bfo_tokens values (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11)', row)
            conn_db.commit()

# получение токена авторизации
time_start = datetime.now().strftime('%H:%M')
(token, expires, tokenT0, header) = getToken()

report_year = 2023
size = 2000

# кол-во страниц 
( status, totalPages ) = getPageAmount( report_year, token, size, header)
if (status != requests.codes.ok) or (totalPages is None):
    print('не удалось вычислить размер данных')
    pass
else:
    print('totalPages: {}'.format(totalPages))

T0 = time.time()

odb.init_oracle_client()
User = 'SB_DMAS'
Psw = '*'
User = 'SB_DKA'
Psw = '*'
Params = odb.ConnectParams(host='e30-scan.fc.uralsibbank.ru', port='1522', service_name = 'cdw.work')
conn_db = odb.connect(user=User, password=Psw, params = Params)

for page in range(1, totalPages+1):
    delta = time.time() - tokenT0
    if delta >= expires:
        (token, expires, tokenT0, header) = getToken()
    (status, page_data)  = getFileTokens(report_year, token, page, size, header) 
    delta_time = round((time.time() - T0)/60, 1)    
    print('D(t)= {}, st.= {}, page= {}, errors {}'.format(delta_time, status, page, error_amount))    
    if status == requests.codes.ok:
        SavePage2db( page_data, page )        

print('success_amount= ', success_amount)                



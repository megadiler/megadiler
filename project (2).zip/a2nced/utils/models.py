import pandas as pd
import numpy as np
import datetime as dt
import os
import sys

from lifetimes import BetaGeoFitter
from lifetimes.utils import summary_data_from_transaction_data
from faker import Faker
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OrdinalEncoder, OneHotEncoder
from lightgbm import LGBMClassifier
# from imblearn.over_sampling import SMOTENC
from sklearn.metrics import roc_auc_score, accuracy_score, plot_roc_curve
import math
from functools import partial

from hyperopt import hp, fmin, tpe, Trials, STATUS_OK
from hyperopt.pyll.base import scope



search_space = {
    'classifier__num_leaves': scope.int(hp.quniform('num_leaves', 10, 101, 1)),
    'classifier__max_depth': scope.int(hp.quniform('max_depth', 3, 15, 1)),
    'classifier__learning_rate': hp.uniform('learning_rate', 0.001, 0.5),
    'classifier__n_estimators': scope.int(hp.quniform('n_estimators', 100, 1000, 50)),
    'classifier__reg_alpha': hp.uniform('reg_alpha', 0.1, 1),
    'classifier__reg_lambda': hp.uniform('reg_lambda', 0.1, 1)
}


def unpack_model_params(params:dict):
    best_params = dict()
    best_params['classifier__num_leaves'] = int(params.get('num_leaves', 31))
    best_params['classifier__max_depth'] = int(params.get('max_depth', -1))
    best_params['classifier__learning_rate'] = params.get('learning_rate', 0.1)
    best_params['classifier__n_estimators'] = int(params['n_estimators'])
    best_params['classifier__reg_alpha'] = params.get('reg_alpha', 0.0)
    best_params['classifier__reg_lambda'] = params.get('reg_lambda', 0.0)
    best_params['classifier__objective'] = "binary"
    best_params['classifier__random_state'] = 42
    best_params['classifier__n_jobs'] = 8
    return(best_params)


def create_pipeline(cat_features, numer_features, model):
    numeric_transformer = Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='mean')),
            ('scaler', StandardScaler())
        ])

    categorical_transformer = Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='constant')),
            ('encoder', OneHotEncoder(handle_unknown='ignore'))
        ])

    preprocessor = ColumnTransformer(
        transformers=[
        ('numeric', numeric_transformer, numer_features),
        ('categorical', categorical_transformer, cat_features)])

    pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('classifier', model)])

    return(pipeline)



def objective(params, pipeline,  X_train, y_train):
    """
    Кросс-валидация с текущими гиперпараметрами

    :params: параметры
    :pipeline: модель
    :X_train: матрица признаков
    :y_train: вектор меток объектов
    :return: средняя точность на кросс-валидации
    """ 
    # задаём модели требуемые параметры    
    pipeline.set_params(**params)

    # задаём параметры кросс-валидации (стратифицированная 4-фолдовая с перемешиванием)
    skf = StratifiedKFold(n_splits=4, shuffle=True, random_state=1)

    # проводим кросс-валидацию  
    score = cross_val_score(estimator=pipeline, X=X_train, y=y_train, 
                            scoring='roc_auc', cv=skf, n_jobs=-1)

    # возвращаем результаты, которые записываются в Trials()
    return({'loss': -score.mean(), 'params': params, 'status': STATUS_OK})


def param_search(pipeline: sklearn.pipeline.Pipeline,
                 X_train: pd.DataFrame,
                 y_train:pd.DataFrame,
                 search_space:dict,
                num_epochs:int=100) -> dict:
    """
    Модель для поиска оптимальных параметров модели
    :pipeline: пайплан, содержащий препроцессор данных и модель для подбора параметров
    :X_train: датафрейм с признаковым описанием объектов
    :y_train: датафрейм с реальными метками классов
    :search-space: словарь, сожержащий возможные параметры модели
    """
    trials = Trials()
    best = fmin( 
        # функция для оптимизации
        fn=partial(objective, pipeline=pipeline, X_train=X_train, y_train=y_train),
        # пространство поиска
        space=search_space,
        # алгоритм поиска
        algo=tpe.suggest,
        # число итераций
        # (можно ещё указать и время поиска)
        max_evals=num_epochs,
        # куда сохранять историю поиска
        trials=trials,
        # random state
        rstate=np.random.default_rng(42),
        # progressbar
        show_progressbar=True
    )
    return(best)


# опишем функцию, которая позволит нам балансировать выборки
def create_stratified_sample(df:pd.DataFrame,
                             column_name:str,
                             test_size:float) -> tuple:
    """
    Args:
    =====
    df: pd.DataFrame
    initial dataframe
    
    column_name: str
    column name, using for stratification
    
    test_size: float, range (0.0, 1.0)
    size of test sample as a part of the population
    
    """
    if test_size > 1:
        raise KeyError('use floats from range (0.0, 1.0)')
    # number of items in test sample
    n = int(df.shape[0] * test_size) + 1
    test_df = df.sample(n)
    
    control_df = pd.DataFrame(columns = test_df.columns.values)
    
    num_groups = test_df[column_name].nunique()

    for i in range(num_groups):
        m = int(test_df[test_df[column_name]== i].shape[0])
        control = df[(~df.user_id.isin(test_df.user_id.values)) &\
                     (df[column_name] == i)].sample(m)
        control_df = pd.concat([control_df, control], axis=0)
        
    return(test_df,
          control_df)
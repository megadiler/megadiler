import itertools
import numpy as np
import matplotlib.pyplot as plt
import sklearn
from sklearn.metrics import f1_score, precision_score, recall_score, confusion_matrix
import scikitplot as skplt
import warnings


def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    # if normalize:
        #cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        #print("Normalized confusion matrix")
    #else:
        #print('Confusion matrix, without normalization')

    #print(cm)

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.4f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()

def plot_metrics(y_test, y_predicted, threshold=0.05):
    #skplt.metrics.plot_cumulative_gain(y_test, y_predicted)
    #skplt.metrics.plot_lift_curve(y_test, y_predicted)
    #skplt.metrics.plot_roc(y_test, y_predicted)
    
    #precision, recall, thresholds = skplt.metrics.precision_recall_curve(y_test, y_predicted[:,1])
    #fig, ax = plt.subplots(figsize=(6,6))
    #ax.plot(recall, precision, label='Model')
    #baseline = len(y_test[y_test==1]) / len(y_test)
    #ax.plot([0, 1], [baseline, baseline], linestyle='--', label='Baseline')
    #ax.set_xlabel('Recall')
    #ax.set_ylabel('Precision')
    #ax.legend(loc='center right')
   # 
    y_classes = np.where(y_predicted[:,1]>= threshold, 1. , 0.)
    cnf_matrix = confusion_matrix(y_test, y_classes)
    class_names = ['Не купили', 'Купили']

    #plt.figure()
    plot_confusion_matrix(cnf_matrix, classes=class_names,
                        title='Confusion matrix, without normalization')

    # # Plot normalized confusion matrix
    # plt.figure()
    # plot_confusion_matrix(cnf_matrix, classes=class_names, normalize=True,
    #                     title='Normalized confusion matrix')
    
    print(f"""
    precision: {precision_score(y_test, y_classes)} 
    recall: {recall_score(y_test, y_classes)} 
    f1: {f1_score(y_test, y_classes)}
    """
    )

def eval_metrics(actual, pred):
    cm = confusion_matrix(actual, pred)
    tn = cm[0][0]
    fn = cm[1][0]
    tp = cm[1][1]
    fp = cm[0][1]

    # Precision or positive predictive value
    # точность положительного класса
    ppv = tp/(tp+fp)
    # Negative predictive value
    # Отрицательная прогностическая ценность
    # точность отрицательного класса
    npv = tn/(tn+fn)

    # Overall accuracy
    # Общая точность
    acc = (tp+tn)/(tp+fp+fn+tn)
    f1 = f1_score(actual, pred)
    return ppv, npv, acc, f1



def get_feature_names(column_transformer):
    """Get feature names from all transformers.
    Returns
    -------
    feature_names : list of strings
        Names of the features produced by transform.
    """
    # Remove the internal helper function
    #check_is_fitted(column_transformer)
    
    # Turn loopkup into function for better handling with pipeline later
    def get_names(trans):
        # >> Original get_feature_names() method
        if trans == 'drop' or (
                hasattr(column, '__len__') and not len(column)):
            return []
        if trans == 'passthrough':
            if hasattr(column_transformer, '_df_columns'):
                if ((not isinstance(column, slice))
                        and all(isinstance(col, str) for col in column)):
                    return column
                else:
                    return column_transformer._df_columns[column]
            else:
                indices = np.arange(column_transformer._n_features)
                return ['x%d' % i for i in indices[column]]
        if not hasattr(trans, 'get_feature_names'):
        # >>> Change: Return input column names if no method avaiable
            # Turn error into a warning
            warnings.warn("Transformer %s (type %s) does not "
                                 "provide get_feature_names. "
                                 "Will return input column names if available"
                                 % (str(name), type(trans).__name__))
            # For transformers without a get_features_names method, use the input
            # names to the column transformer
            if column is None:
                return []
            else:
                return [name + "__" + f for f in column]

        return [name + "__" + f for f in trans.get_feature_names()]
    
    ### Start of processing
    feature_names = []
    
    # Allow transformers to be pipelines. Pipeline steps are named differently, so preprocessing is needed
    if type(column_transformer) == sklearn.pipeline.Pipeline:
        l_transformers = [(name, trans, None, None) for step, name, trans in column_transformer._iter()]
    else:
        # For column transformers, follow the original method
        l_transformers = list(column_transformer._iter(fitted=True))
    
    
    for name, trans, column, _ in l_transformers: 
        if type(trans) == sklearn.pipeline.Pipeline:
            # Recursive call on pipeline
            _names = get_feature_names(trans)
            # if pipeline has no transformer that returns names
            if len(_names)==0:
                _names = [name + "__" + f for f in column]
            feature_names.extend(_names)
        else:
            feature_names.extend(get_names(trans))
    
    return feature_names



def find_angle(x: np.array, y: np.array):
    inner = np.inner(x, y)
    norms = np.linalg.norm(x) * np.linalg.norm(y)
    cos = inner / norms
    rad = np.arccos(np.clip(cos, -1.0, 1.0))
    deg = np.rad2deg(rad)
    return(deg)


def find_inflection_point(data, x_col, y_col, num_examples, step=10):
    anlgle = None
    for i in range(0, num_examples, step):
        x_1 = data.iloc[i,  x_col]
        x_2 = data.iloc[i + step, x_col]
        y_1 = data.iloc[i, y_col]
        y_2 = data.iloc[i  + step, y_col]
        vect_1 = np.array([x_1 - x_2, y_1 - y_2])
        vect_2 = np.array([x_1 - x_2, 0.0])
        angle = find_angle(vect_1, vect_2)
        i += step
        if angle < 45.0:
            break
    return(int(i +  step / 2))
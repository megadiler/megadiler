import numpy as np
import pandas as pd
import datetime as dt
from faker import Faker


def default_date_generator() -> dt.date:
    """
    Возвращает дату первого события указанного набора данных
    """
    Faker.seed(0)
    fake = Faker()

    start = dt.date(year=2015, month=1, day=1)
    end = dt.date(year=2020, month=12, day=31)
    # чтобы ничего не сломалось, нам нужен понедельник
    default_date = fake.date_between_dates(date_start=start, date_end=end)
    while default_date.weekday() != 0:
        default_date = fake.date_between_dates(date_start=start, date_end=end)

    return(default_date)


def default_date_parser(date:str):
    return(dt.datetime.strptime(date, '%Y-%m-%d %H:%M:%S'))
    

def get_week_end_date(week:int, weeks: pd.DataFrame) -> dt.date:
    """Преобразует номер недели в исследовании в дату ее окончания"""
    return(pd.to_datetime(weeks.loc[weeks['week'] == week]['to'].values[0]))


def convert_to_date(x, default_date=None):
    if default_date is None:
        default_date = default_date_generator()
    return(default_date + dt.timedelta(days=x))


# определим функции, которых нет в Pandas
def vals_range(x:np.array, axis:int=0):
    return(np.max(x, axis=axis) - np.min(x, axis=axis))


def quantile_25(x:np.array):
    return(x.quantile(q=.25))


def quantile_75(x:np.array):
    return(x.quantile(q=.75))


def interquantile_range(x:np.array):
    return(quantile_75(x) - quantile_25(x))

def skewness(x:np.array):
    return(x.skew())



def get_feature_matrix(orders_df:pd.DataFrame,
                      date:str,
                      period_1:int=14,
                      period_2:int=30,
                      period_3:int=60,
                      demogr_df:pd.DataFrame=None) -> pd.DataFrame:
    end_date = dt.datetime.strptime(date, '%Y-%m-%d')
    # period_1 (14 дней)
    start_14_days = end_date - dt.timedelta(days=14) 
    # period_2 (30 дней)
    start_30_days = end_date - dt.timedelta(days=30) 
    # period_3 (60 дней)
    start_60_days = end_date - dt.timedelta(days=60)
    available_ids = demogr_df['user_id'].values
    agg_features_14 = orders_df.loc[(orders_df.user_id.isin(available_ids)) &\
              (orders_df.purch_date_time >= start_14_days) &\
              (orders_df.purch_date_time <= end_date)].\
    groupby('user_id')[['quantity', 'sales_value', 'retail_disc', 'default_price']].\
    agg(['min', 'max', 'mean', 'median', 'std', 'sum', vals_range,
        quantile_25, quantile_75, interquantile_range, skewness], axis=1).reset_index()
    agg_features_14.columns = agg_features_14.columns.to_flat_index().str.join('_')
    
    agg_features_30 = orders_df.loc[(orders_df.user_id.isin(available_ids)) &\
                  (orders_df.purch_date_time >= start_30_days) &\
                  (orders_df.purch_date_time <= end_date)].\
    groupby('user_id')[['quantity', 'sales_value', 'retail_disc', 'default_price']].\
    agg(['min', 'max', 'mean', 'median', 'std', 'sum', vals_range,
        quantile_25, quantile_75, interquantile_range, skewness], axis=1).reset_index()
    agg_features_30.columns = agg_features_30.columns.to_flat_index().str.join('_')


    agg_features_60 = orders_df.loc[(orders_df.user_id.isin(available_ids)) &\
                  (orders_df.purch_date_time >= start_60_days) &\
                  (orders_df.purch_date_time <= end_date)].\
    groupby('user_id')[['quantity', 'sales_value', 'retail_disc', 'default_price']].\
    agg(['min', 'max', 'mean', 'median', 'std', 'sum', vals_range,
        quantile_25, quantile_75, interquantile_range, skewness], axis=1).reset_index()
    agg_features_60.columns = agg_features_60.columns.to_flat_index().str.join('_')
    
    agg_features_14.rename({'user_id_':'user_id'}, axis=1, inplace=True)
    agg_features_30.rename({'user_id_':'user_id'}, axis=1, inplace=True)
    agg_features_60.rename({'user_id_':'user_id'}, axis=1, inplace=True)
    
    df = demogr_df[['user_id', 'age_desc', 'income_desc', 'no_kids']]
    common_cols = ['user_id',]
    
    agg_features_14.columns = agg_features_14.columns.map(lambda x: f'{x}_14_days' if x not in common_cols else str(x))
    agg_features_30.columns = agg_features_30.columns.map(lambda x: f'{x}_30_days' if x not in common_cols else str(x))
    agg_features_60.columns = agg_features_60.columns.map(lambda x: f'{x}_60_days' if x not in common_cols else str(x))
    df = df.merge(agg_features_14, how='left')
    df = df.merge(agg_features_30, how='left')
    return(df.merge(agg_features_60, how='left'))
